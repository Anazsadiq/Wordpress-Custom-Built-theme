<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Shortcode Header
 */

// Shortcode fields configuration
if ( !function_exists( 'like_vc_sliders_params' ) ) {

	function like_vc_sliders_params() {

		$fields = array(

			array(
				"param_name" => "type",
				"heading" => esc_html__("Type", 'like-themes-plugins'),
				"std" => "default",
				"admin_label" => true,
				"value" => array(
					esc_html__('Swiper Horizontal Slider', 'like-themes-plugins') 		=> 'slider-swiper',
					esc_html__('Zoom Gallery Slider', 'like-themes-plugins') 			=> 'slider-zoom',
				),
				"type" => "dropdown"
			),		
			array(
				"param_name" => "align",
				"heading" => esc_html__("Swiper Align", 'like-themes-plugins'),
				"description" => esc_html__("Only for Swiper Slider", 'like-themes-plugins'),
				"std" => "center",
				"admin_label" => true,
				"value" => array(
					esc_html__('Center', 'like-themes-plugins') 	=> 'center',
					esc_html__('Left', 'like-themes-plugins') 		=> 'left',
					esc_html__('Right', 'like-themes-plugins') 	=> 'right',
				),
				"type" => "dropdown"
			),					
			array(
				'type' => 'param_group',
				'param_name' => 'slides',
				'heading' => esc_html__( 'Slides', 'like-themes-plugins' ),
				"description" => esc_html__("Add Slides", 'like-themes-plugins'),
				'value' => urlencode( json_encode( array(
					array(
						'image' => '',
					),
				) ) ),
				'params' => array(
					array(
						"param_name" => "image",
						"heading" => esc_html__("Image", 'like-themes-plugins'),
						"type" => "attach_image"
					),
					array(
						"param_name" => "text",
						"heading" => esc_html__("Description", 'like-themes-plugins'),
						"type" => "textarea"
					),
					array(
						"param_name" => "href",
						"heading" => esc_html__("Read More Link", 'like-themes-plugins'),
						"description" => esc_html__("Not required", 'like-themes-plugins'),
						"type" => "textfield"
					),					
					array(
						"param_name" => "btn_header",
						"heading" => esc_html__("Read More Header", 'like-themes-plugins'),
						"type" => "textfield"
					),										
				),
			),
			array(
				"param_name" => "zs_speed",
				"heading" => esc_html__("Zoom Effect Speed, ms", 'like-themes-plugins'),
				"std" => 12000,
				"admin_label" => true,
				"type" => "textfield"
			),			
			array(
				"param_name" => "zs_interval",
				"heading" => esc_html__("Interval between slides, ms", 'like-themes-plugins'),
				"std" => 7000,
				"admin_label" => true,
				"type" => "textfield"
			),			
		);

		return $fields;
	}
}

// Add Wp Shortcode
if ( !function_exists( 'like_sc_sliders' ) ) {

	function like_sc_sliders($atts, $content = null) {	

		$atts = like_sc_atts_parse('like_sc_sliders', $atts, array_merge( array(

			'type'		=> '',
			'align'		=> '',
			'zs_speed'		=> '12000',
			'zs_interval'		=> '7000',
			'slides' 	=> '',

			), array_keys(like_vc_default_params(true)) )
		);

		$atts['slides'] = json_decode ( urldecode( $atts['slides'] ), true );

		if (!empty($atts['slides'])) {

			return like_sc_output('sliders', $atts, $content);
		}
			else {

			return false;
		}
	}

	if (like_vc_inited()) add_shortcode("like_sc_sliders", "like_sc_sliders");
}


// Adding shortcode to VC
if (!function_exists('like_vc_sliders_add')) {

	function like_vc_sliders_add() {
		
		vc_map( array(
			"base" => "like_sc_sliders",
			"name" 	=> esc_html__("Sliders", 'like-themes-plugins'),
			"description" => esc_html__("Sliders", 'like-themes-plugins'),
			"class" => "like_sc_sliders",
//			"icon"	=>	likeGetPluginUrl('/shortcodes/header/icon.png'),

			"is_container" => true,
			"js_view" => 'VcColumnView',
			"category" => esc_html__('Like-Themes', 'like-themes-plugins'),
			'content_element' => true,
			"params" => array_merge(
				like_vc_sliders_params(),
				like_vc_default_params()
			),
		) );

		if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
		    class WPBakeryShortCode_Like_Sc_Sliders extends WPBakeryShortCodesContainer {
		    }
		}
	}

	if (like_vc_inited()) add_action('vc_before_init', 'like_vc_sliders_add', 30);
}


