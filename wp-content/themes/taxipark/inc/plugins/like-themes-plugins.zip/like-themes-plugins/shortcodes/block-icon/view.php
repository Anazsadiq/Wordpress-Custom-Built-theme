<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Block Icons Shortcode
 */

$args = get_query_var('like_sc_block_icon');

echo '<ul class="block-icon '. esc_attr($atts['type']) . ' ' . esc_attr($atts['rounded']) .'">';
	foreach ( $atts['icons'] as $item ) {

		$li_class = '';


		if (!empty($item['icon_fontawesome'])) {

			$a_class = $item['icon_fontawesome'];
		}
			else {

			$a_class = 'icon-text';
		}

		$href_tag1 = $href_tag2 = '';
		$div_tag1 = $div_tag2 = '';

		if ($atts['type'] == 'icon-ht-right') {

			$div_tag1 = '<div class="block-right">';
			$div_tag2 = '</div>';
		}

		if (!empty($item['href'])) {

			$href_tag1 = '<a href="'. esc_url( $item['href'] ) .'" class="'. esc_attr( $a_class ) .'">';
			$href_tag2 = '</a>';
		}
			else {

			if (empty($item['icon_text'])) $item['icon_text'] = '';

			$href_tag1 = '<span class="'. esc_attr( $a_class ) . '">' . esc_html( $item['icon_text'] );
			$href_tag2 = '</span>';
		}

		echo '<li>' . $href_tag1 . $href_tag2 . $div_tag1 . ' <h4> ' . esc_html( $item['header'] )  .  ' </h4><div>'. esc_html( $item['descr'] ) . $div_tag2 . '</div></li>';

	}
echo '</ul>';

