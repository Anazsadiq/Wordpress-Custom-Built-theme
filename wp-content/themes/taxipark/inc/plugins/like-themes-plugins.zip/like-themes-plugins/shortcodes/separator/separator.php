<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Shortcode separator
 */

// Shortcode fields configuration
if ( !function_exists( 'like_vc_separator_params' ) ) {

	function like_vc_separator_params() {

		$fields = array(
	
		);

		return $fields;
	}
}

// Add Wp Shortcode
if ( !function_exists( 'like_sc_separator' ) ) {

	function like_sc_separator($atts, $content = null) {	

		$atts = array();
		return like_sc_output('separator', $atts, $content);
	}

	if (like_vc_inited()) add_shortcode("like_sc_separator", "like_sc_separator");
}


// Adding shortcode to VC
if (!function_exists('like_vc_separator_add')) {

	function like_vc_separator_add() {
		
		vc_map( array(
			"base" => "like_sc_separator",
			"name" 	=> esc_html__("Taxi Separator", 'like-themes-plugins'),
			"description" => esc_html__("Custom separator", 'like-themes-plugins'),
			"class" => "like_sc_separator",
//			"icon"	=>	likeGetPluginUrl('/shortcodes/separator/icon.png'),
			"show_settings_on_create" => false,
			"category" => esc_html__('Like-Themes', 'like-themes-plugins'),
			'content_element' => true,
			"params" => array_merge(
				like_vc_separator_params(),
				like_vc_default_params()
			)
		) );
	}

	if (like_vc_inited()) add_action('vc_before_init', 'like_vc_separator_add', 30);
}


