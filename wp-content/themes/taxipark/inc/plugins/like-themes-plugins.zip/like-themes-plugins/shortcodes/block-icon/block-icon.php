<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Shortcode Header
 */

// Shortcode fields configuration
if ( !function_exists( 'like_vc_block_icon_params' ) ) {

	function like_vc_block_icon_params() {

		$fields = array(

			array(
				"param_name" => "type",
				"heading" => esc_html__("List type", 'like-themes-plugins'),
				"std" => "default",
				"value" => array(
					esc_html__('Icon Left, Header and Text Right', 'like-themes-plugins') 	=> 'icon-ht-right',
					esc_html__('Icon Left, Header Right', 'like-themes-plugins') 			=> 'icon-h-right',
					esc_html__('Icon Top', 'like-themes-plugins') 							=> 'icon-top',
				),
				"type" => "dropdown"
			),		
			array(
				"param_name" => "rounded",
				"heading" => esc_html__("Borders Type", 'like-themes-plugins'),
				"std" => "i-square",
				"value" => array(
					esc_html__('Square', 'like-themes-plugins') 		=> 'i-square',
					esc_html__('Circle', 'like-themes-plugins') 		=> 'i-circle',
				),
				"type" => "dropdown"
			),					
			array(
				'type' => 'param_group',
				'param_name' => 'icons',
				'heading' => esc_html__( 'Icons', 'like-themes-plugins' ),
				"description" => wp_kses_data( __("Select icons, specify title and/or description for each item", 'like-themes-plugins') ),
				'value' => urlencode( json_encode( array(
					array(
						'header' => '',
						'size' => 'default',
						'href' => '',
						'icon_fontawesome' => 'empty',
					),
				) ) ),
				'params' => array(
					array(
						'param_name' => 'header',
						'heading' => esc_html__( 'Header', 'like-themes-plugins' ),
						'type' => 'textfield',
						'admin_label' => true,
					),
					array(
						'param_name' => 'descr',
						'heading' => esc_html__( 'Description', 'like-themes-plugins' ),
						'type' => 'textarea',
						'admin_label' => false,
					),					
/*					
					array(
						"param_name" => "fill",
						"heading" => esc_html__("Background", 'like-themes-plugins'),
						"std" => "default",
						"value" => array(
							esc_html__('Filled', 'like-themes-plugins') 		=> 'default',
							esc_html__('Transparent', 'like-themes-plugins') 		=> 'large',
						),
						"type" => "dropdown"
					),			
					
*/													
					array(
						'param_name' => 'href',
						'heading' => esc_html__( 'Href', 'like-themes-plugins' ),
						'type' => 'textfield',
						'description' => esc_html__( 'URL to list item', 'like-themes-plugins' ),
					),
					array(
						'param_name' => 'icon_fontawesome',
						'heading' => esc_html__( 'Icon', 'like-themes-plugins' ),
						'type' => 'iconpicker',
						'admin_label' => true,						
						'value' => '',
						'settings' => array(
							'emptyIcon' => true,
							'type' => 'fontawesome'

						),
					),
					array(
						'param_name' => 'icon_text',
						'heading' => esc_html__( 'Or Icon Text', 'like-themes-plugins' ),
						'type' => 'textfield',
						'description' => esc_html__( 'Text Header as Icon', 'like-themes-plugins' ),
					),										
				),
			),
		);

		return $fields;
	}
}

// Add Wp Shortcode
if ( !function_exists( 'like_sc_block_icon' ) ) {

	function like_sc_block_icon($atts, $content = null) {	

		$atts = like_sc_atts_parse('like_sc_header', $atts, array_merge( array(

			'type'		=> '',
			'rounded'		=> '',			
			'icons' 	=> '',

			), array_keys(like_vc_default_params(true)) )
		);

		$atts['icons'] = json_decode ( urldecode( $atts['icons'] ), true );

		if (!empty($atts['icons'])) {

			return like_sc_output('block-icon', $atts, $content);
		}
			else {

			return false;
		}
	}

	if (like_vc_inited()) add_shortcode("like_sc_block_icon", "like_sc_block_icon");
}


// Adding shortcode to VC
if (!function_exists('like_vc_block_icon_add')) {

	function like_vc_block_icon_add() {
		
		vc_map( array(
			"base" => "like_sc_block_icon",
			"name" 	=> esc_html__("Block with Icon", 'like-themes-plugins'),
			"description" => esc_html__("Text Block with Icon", 'like-themes-plugins'),
			"class" => "like_sc_block_icon",
//			"icon"	=>	likeGetPluginUrl('/shortcodes/header/icon.png'),
			"show_settings_on_create" => true,
			"category" => esc_html__('Like-Themes', 'like-themes-plugins'),
			'content_element' => true,
			"params" => array_merge(
				like_vc_block_icon_params(),
				like_vc_default_params()
			)
		) );
	}

	if (like_vc_inited()) add_action('vc_before_init', 'like_vc_block_icon_add', 30);
}


