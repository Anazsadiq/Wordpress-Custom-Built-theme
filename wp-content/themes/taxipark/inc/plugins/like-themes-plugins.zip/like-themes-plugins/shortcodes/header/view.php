<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * HR Shortcode
 */

$args = get_query_var('like_sc_header');

$class = '';
if ( !empty($args['size']) AND $args['size'] != 'default' ) $class .= ' heading-'.$args['size'];
if ( !empty($args['style']) AND $args['style'] != 'default' ) $class .= ' '.$args['style'];
if ( !empty($args['align']) AND $args['align'] != 'default' ) $class .= ' align-'.$args['align'];

if ( !empty($args['class']) ) $class .= ' '. esc_attr($args['class']);
if ( !empty($args['id']) ) $id = ' id="'. esc_attr($args['id']). '"'; else $id = '';

echo '<div class="heading '. esc_attr( $class ) .'"'. $id .'>';

if ( !empty($args['subheader']) AND $args['style'] != 'inline' ) {

	echo '<h4>'. esc_html( trim( $args['subheader'] ) ) .'</h4>';
}

if (!empty($args['header'])) {

	if ( !empty($args['type']) ) {

		$tag = $args['type'];
	}

	echo '<'. esc_attr($tag) .'>';
	if ( !empty($args['icon_fontawesome']) AND $args['icon_type'] == 'default' ) {

		echo '<span class="icon-'. esc_attr( $args['icon_type'] ).' '. esc_attr($args['icon_fontawesome']) .'"></span>';
	}

	if ( !empty($args['link']) ) {

		echo '<a href="'.esc_url($args['link']).'">' . esc_html( $args['header'] ) . '</a>';
	}
		else {

		echo esc_html( $args['header'] );
	}

	if ( $args['style'] == 'inline' ) {

		echo ' <span>'. esc_html( trim( $args['subheader'] ) ) .'</span>';
	}

	echo '</'. esc_attr($tag) .'>';
}

if (!empty($args['text'])) {

	echo '<p class="header-text">'. esc_html( $args['text'] ) .'</p>';
}

if ( !empty($args['icon_fontawesome']) AND $args['icon_type'] == 'bg' ) {

	echo '<span class="icon-'. esc_attr( $args['icon_type'] ).' '. esc_attr($args['icon_fontawesome']) .'"></span>';
}


echo '</div>';

