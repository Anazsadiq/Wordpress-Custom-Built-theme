<div class="page_container>
    
    
    <?php
    the_content();
    ?>


</div>