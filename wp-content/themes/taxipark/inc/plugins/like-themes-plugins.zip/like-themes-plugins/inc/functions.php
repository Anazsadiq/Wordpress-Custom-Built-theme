<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * LikeThemes Plugins Functions
 */

include LTX_PLUGIN_DIR . 'inc/ltx-dashboard.php';
include LTX_PLUGIN_DIR . 'inc/update.php';


// Get Local Path of include file
function likeGetLocalPath($file) {

	global $like_cfg;

	return $like_cfg['path'].$like_cfg['base'].$file;
}

// Get Plugin Url
function likeGetPluginUrl($file) {

	global $like_cfg;

	return $like_cfg['url'].$file;
}

// Get Visual Composer plugin status
if ( !function_exists( 'like_vc_inited' ) ) {

	function like_vc_inited() {
		
		return class_exists('Vc_Manager');
	}
}

// Generate img url
if (!function_exists('like_get_attachment_img_url')) {
	function like_get_attachment_img_url( $img, $size = 'full' ) {
		if ($img > 0) {

			return wp_get_attachment_image_src($img, 'full');
		}
	}
}


