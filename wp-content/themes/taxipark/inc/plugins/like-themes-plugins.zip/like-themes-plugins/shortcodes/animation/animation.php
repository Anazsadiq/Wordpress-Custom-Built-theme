<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Shortcode animation
 */

// Shortcode fields configuration
if ( !function_exists( 'like_vc_animation_params' ) ) {

	function like_vc_animation_params() {

		$fields = array(

			array(
				"param_name" => "image",
				"heading" => esc_html__("Image", 'like-themes-plugins'),
				"type" => "attach_image",
				"admin_label" => true,				
			),
			array(
				"param_name" => "type",
				"heading" => esc_html__("Animation Type", 'like-themes-plugins'),
				"std" => "slide-from-right",
				"admin_label" => true,				
				"value" => array(
					esc_html__('Slide From Right', 'like-themes-plugins') => 'slide-from-right',
					esc_html__('Zoom to Center', 'like-themes-plugins') => 'zoom-center',
					esc_html__('Static dialog block', 'like-themes-plugins') => 'static-center',
				),
				"type" => "dropdown"
			),
			array(
				"param_name" => "content",
				"holder" => "div",
				"heading" => esc_html__("Text", 'like-themes-plugins'),
				"description" => esc_html__("Additional text", 'like-themes-plugins'),
				"type" => "textarea_html"
			),				
		);

		return $fields;
	}
}

// Add Wp Shortcode
if ( !function_exists( 'like_sc_animation' ) ) {

	function like_sc_animation($atts, $content = null) {	

		$atts = like_sc_atts_parse('like_sc_animation', $atts, array_merge( array(

			'type'		=> 'slider-from-right',
			'image'		=> '',
			), array_keys(like_vc_default_params(true)) )
		);

		$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content

		return like_sc_output('animation', $atts, $content);
	}

	if (like_vc_inited()) add_shortcode("like_sc_animation", "like_sc_animation");
}


// Adding shortcode to VC
if (!function_exists('like_vc_animation_add')) {

	function like_vc_animation_add() {
		
		vc_map( array(
			"base" => "like_sc_animation",
			"name" 	=> esc_html__("Taxi Car Animation", 'like-themes-plugins'),
			"description" => esc_html__("Animation Block", 'like-themes-plugins'),
			"class" => "like_sc_animation",
//			"icon"	=>	likeGetPluginUrl('/shortcodes/header/icon.png'),
			"show_settings_on_create" => true,
			"category" => esc_html__('Like-Themes', 'like-themes-plugins'),
			'content_element' => true,
			'is_container' => true,			
			"params" => array_merge(
				like_vc_animation_params(),
				like_vc_default_params()
			)
		) );

		if ( class_exists( 'WPBakeryShortCode' ) ) {
			class WPBakeryShortCode_Like_Sc_Animation extends WPBakeryShortCode {}
		}

	}

	if (like_vc_inited()) add_action('vc_before_init', 'like_vc_animation_add', 30);
}


