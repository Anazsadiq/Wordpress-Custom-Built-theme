<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Button Shortcode
 */

$args = get_query_var('like_sc_animation');

if ($args['type'] == 'slide-from-right') {

		$image = like_get_attachment_img_url( $args['image'] );
		echo '<div class="car-right animation-block"><img src="' . $image[0] . '" class="full-width" alt="animation"></div>';	
}

if ($args['type'] == 'static-center') {

		$image = like_get_attachment_img_url( $args['image'] );
		echo '<div class="large-image-center">
			<img src="' . $image[0] . '" class="full-width" alt="animation">
			<div class="dialog">
				<span class="fa fa-phone"></span>
				'. wp_kses_post( $content ) .'
			</div>
		</div>';	
}


if ($args['type'] == 'zoom-center') {

		$image = like_get_attachment_img_url( $args['image'] );
		echo '<div class="large-image-center">
			<img src="' . $image[0] . '" class="full-width" alt="animation">
			<img src="' . esc_attr( get_template_directory_uri() . '/assets/images/_car-splash.png' ) .'" class="splash" alt="Taxi">
		</div>';	
}


