<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Shortcodes Init
 * https://codex.wordpress.org/Shortcode_API 
 */


if ( !function_exists('likethemes_sc_init') ) {

	function likethemes_sc_init() {

		$shortcodes_array = array(

			'animation'		=>	true,
			'alert'			=>	true,			
			'header'		=>	true,
			'team'		=>	true,			
			'tariff'		=>	true,
			'google_maps'	=>	true,
			'block-icon'	=>	true,			
			'social-icons'	=>	true,
			'separator'		=>	true,
			'sliders'		=>	true,
			'button'		=>	true,
			'testimonials'	=>	true,
		);

		foreach ($shortcodes_array as $item => $enabled) {

			$sc_include = likeGetLocalPath( '/shortcodes/' . $item . '/' . $item . '.php' );
			if ( $enabled AND file_exists( $sc_include ) ) {

				include_once $sc_include;
			}
		}
	}
}
add_action( 'after_setup_theme', 'likethemes_sc_init', 100 );

/**
 * Default fields for all shortcodes
 */
if ( !function_exists( 'like_vc_default_params' ) ) {

	function like_vc_default_params($ids = false) {

		$group = esc_html__('Attributes', 'like-themes-plugins');

		$fields = array(

			'id' => array(
				'type'			=> 'textfield',
				'heading' 		=> esc_html__("Element ID", 'like-themes-plugins'),
				'param_name' 	=> "id",
				'admin_label' 	=> true,
				'group'			=> $group,
			),
			'class' => array(
				'type'			=> 'textfield',
				'heading' 		=> esc_html__("Extra class name", 'like-themes-plugins'),
				'param_name' 	=> "class",
				'admin_label'	=> true,
				'group'			=> $group,
			),
		);
		// quickfix for wpbakery 5.6
		if ( $ids === false ) {

			$fields = array_values($fields);
		}

		apply_filters( 'like_vc_default_params', $fields );

		return $fields;
	}
}

/**
 * Adding VC params
 */
if ( !function_exists( 'like_vc_add_params' ) ) {

	function like_vc_add_params() {

		global $like_cfg;

		$colors = array (

			array(
				"type" => "dropdown",
				"heading" => esc_html__("Background Color", 'like-themes-plugins'),
				"description" => esc_html__("Set Background Color from Theme Default Colors", 'like-themes-plugins'),
				"param_name" => "bg_color_select",
				"std"	=>	"transparent",
				"group" => esc_html__('Color Settings', 'like-themes-plugins'),
				"value" => array(
					esc_html__( "Transparent (white)" , 'like-themes-plugins') => "transparent",
					esc_html__( "Theme Main Color (yellow by default)", 'like-themes-plugins' ) => "theme_color",
					esc_html__( "Gray", 'like-themes-plugins' ) => "gray",
					esc_html__( "Black", 'like-themes-plugins' ) => "black",
				),
			),
			array(
				"type" => "dropdown",
				"heading" => esc_html__("Background Overlay", 'like-themes-plugins'),
				"description" => esc_html__("Background overlay effect", 'like-themes-plugins'),
				"param_name" => "bg_overlay",
				"std"	=>	"none",
				"group" => esc_html__('Color Settings', 'like-themes-plugins'),
				"value" => array(
					esc_html__( "None", 'like-themes-plugins' ) => "none",
					esc_html__( "Dark Overlay", 'like-themes-plugins' ) => "dark",
					esc_html__( "Pattern Overlay", 'like-themes-plugins' ) => "pattern",
					esc_html__( "Black Overlay", 'like-themes-plugins' ) => "black",
				),
			),
			array(
				"type" => "dropdown",
				"heading" => esc_html__("Border Box Shadow", 'like-themes-plugins'),
				"description" => esc_html__("Section with Shadow border", 'like-themes-plugins'),
				"param_name" => "border_shadow",
				"std"	=>	"none",
				"group" => esc_html__('Color Settings', 'like-themes-plugins'),
				"value" => array(
					esc_html__( "None", 'like-themes-plugins' ) => "none",
					esc_html__( "Shadowed", 'like-themes-plugins' ) => "shadow",
				),
			),						
		);

		foreach ($colors as $param) {

			vc_add_param("vc_section", $param);
			vc_add_param("vc_row", $param);
			vc_add_param("vc_row_inner", $param);
			vc_add_param("vc_column", $param);
			vc_add_param("vc_column_inner", $param);
		}


		$section_class = array( 
			array(
				"type" => "dropdown",
				"heading" => esc_html__("Like Theme Section Class", 'like-themes-plugins'),
				"description" => esc_html__("Used to style unique theme blocks", 'like-themes-plugins'),
				"param_name" => "theme_section",
				"std"	=>	"none",
				"value" => array_merge(
					array(
						esc_html__( "None", 'like-themes-plugins' ) => "none"
					),
					$like_cfg['like_sections']
				),
			),
		);

		foreach ($section_class as $param) {

			vc_add_param("vc_section", $param);
			vc_add_param("vc_row", $param);
		}		
	}

}

/**
 * Adding new class names to existing VS Shortcodes
 */
if ( !function_exists( 'like_vc_add_element_class' ) ) {

	function like_vc_add_element_class($class = '', $tag, $atts) {

		if ( in_array( $tag, array('vc_section', 'vc_row', 'vc_row_inner', 'vc_column', 'vc_column_inner') ) ) {

			if ( !empty($atts['bg_tone']) AND $atts['bg_tone'] != 'default' ) $class .= esc_attr( ' bg-tone-'.$atts['bg_tone'] );
			if ( !empty($atts['bg_color_select']) AND $atts['bg_color_select'] != 'transparent' ) $class .= esc_attr( ' bg-color-'.$atts['bg_color_select'] );
			if ( !empty($atts['bg_overlay']) AND $atts['bg_overlay'] != 'none' ) $class .= esc_attr( ' bg-overlay-'.$atts['bg_overlay'] );
			if ( !empty($atts['border_shadow']) AND $atts['border_shadow'] != 'none' ) $class .= esc_attr( ' border_shadow ' );

			if ( !empty($atts['theme_section']) AND $atts['theme_section'] != 'none' ) $class .= esc_attr( ' '.$atts['theme_section'] );
		}

		return $class;
	}
}

if ( like_vc_inited() ) {

	vc_set_default_editor_post_types(

		array('page', 'sections')
	);

	add_action( 'after_setup_theme', 'like_vc_add_params', 5 );
	add_filter( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,	'like_vc_add_element_class', 10, 3 );		
}

/**
 * Parsing shortcodes attributing
 */
if (!function_exists('like_sc_atts_parse')) {

	function like_sc_atts_parse($sc, $atts, $default = array()) {


		if (!empty($atts)) {		

			$atts_default = vc_map_get_attributes( $sc, $atts );
			$is_empty = true;
			foreach ($atts_default as $k => $v) {

				if ( empty($atts[$k]) AND !empty($atts_default[$k]) ) {

					$atts[$k] = $v;
				}
			}

			foreach ($atts as &$item) {

				$item = str_replace(array('{{', '}}'), array('<span>', '</span>'), $item);
			}
		}
			else {

			$atts = array();
		}

		unset($item);

		if ( !empty($atts['css']) ) {

			$atts['class'] = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $atts['class'] . ' ' . vc_shortcode_custom_css_class( $atts['css'], ' ' ), $sc, $atts);
			$atts['css'] = '';
		}

		if ( empty($atts['css']) ) {

			$atts['id'] = $sc . '_' . mt_rand();
		}

		$atts = like_html_decode(shortcode_atts(apply_filters('like_sc_atts', $default, $sc), $atts));

 		return apply_filters('like_sc_atts', $atts, $sc);
	}
}

/**
 * Adding shortcode output
 */
if ( !function_exists( 'like_sc_output' ) ) {

	function like_sc_output($sc, $atts, $content = null) {	

		if ( !empty($content) ) $atts['content'] = do_shortcode($content);

		set_query_var('like_sc_' . $sc, $atts);

		$path = likeGetLocalPath('/shortcodes/'.$sc.'/view.php');
		ob_start();
		if (file_exists($path)) include $path;
		$out = ob_get_contents();
		ob_end_clean();

		return $out;
	}
}

if (!function_exists('like_html_decode')) {
	function like_html_decode($string) {
		if ( is_array($string) && count($string) > 0 ) {
			foreach ($string as $key => &$value) {
				if (is_string($value)) {

					$value = htmlspecialchars_decode($value, ENT_QUOTES);
				}
			}
		}
		return $string;
	}
}




/**
 * WP Contact Form 7 Image Select Tag
 */
add_action( 'wpcf7_init', 'like_add_shortcode_car_select' );
function like_add_shortcode_car_select() {
    wpcf7_add_form_tag( 'car_select', 'like_car_select_shortcode_handler', array( 'name-attr' => true ) );
}
 
function like_car_select_shortcode_handler( $tag ) {

	$out = '';

	if ( function_exists( 'fw_get_db_settings_option' ) ) {

		$cars = fw_get_db_settings_option( 'cars' );

		$tag = new WPCF7_FormTag( $tag );

		$atts = array();

		$class = wpcf7_form_controls_class( $tag->type );
		$atts['id'] = $tag->get_id_option();

		$atts['name'] = $tag->name;
		$atts = wpcf7_format_atts( $atts );

		$value = '';

		if ( !empty($cars) ) {

			$out = '<div class="menu-types">';
			foreach ($cars as $key => $item) {

				$class = '';
				if ( !empty($item['vip']) ) $class .= 'red';
				if ( $key == 0 ) {

					$class .= ' active';
					$value = $item['text'];
				}

				$out .= '<a href="#" data-value="'. esc_html($item['text']) .'" class="car-select-'. esc_attr( $key ).' '. esc_attr( $class ).'">'. esc_html($item['text']) .'</a>';
			}
			$out .= '<input type="hidden" class="type-value" value="'. esc_html($value) .'" '.($atts).'></div>';
		}
	} 

    return $out;
}

