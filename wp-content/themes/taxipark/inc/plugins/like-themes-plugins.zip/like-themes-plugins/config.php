<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * TaxiPark Config
 */

$like_cfg = array(

	'path'	=> plugin_dir_path(__DIR__),
	'base' 	=> plugin_basename(__DIR__),
	'url'	=> plugin_dir_url(__FILE__),

	'like_sections'	=> array(

		esc_html__("Services", 'like-themes-plugins') 		=> "services-block",
		esc_html__("Tariffs", 'like-themes-plugins') 		=> "tariffs-block",
		esc_html__("Download App", 'like-themes-plugins') 	=> "download-block",
		esc_html__("Animated Car", 'like-themes-plugins') 	=> "car-block",
		esc_html__("Banners", 'like-themes-plugins') 		=> "banners-block",
		esc_html__("Partners", 'like-themes-plugins') 		=> "partners-block",
		esc_html__("Testimonials", 'like-themes-plugins') 	=> "testimonials-block",
		esc_html__("Top Bar", 'like-themes-plugins') 		=> "top-bar",
		esc_html__("Homepage-1 Top Block", 'like-themes-plugins') => "homepage-block-1",
		esc_html__("Homepage-2 Top Block", 'like-themes-plugins') => "homepage-block-2",
		esc_html__("Homepage-3 Top Block", 'like-themes-plugins') => "homepage-block-3",
		esc_html__("Homepage Address Block", 'like-themes-plugins') => "homepage-block-yellow-3",
		esc_html__("Form Get Taxi Full", 'like-themes-plugins') => "taxi-form-full",
		esc_html__("Form Get Taxi Yellow", 'like-themes-plugins') => "form-taxi-short",
	)
);

add_action( 'plugins_loaded', 'ltx_load_plugin_textdomain' );
if ( !function_exists('ltx_load_plugin_textdomain')) {
	function ltx_load_plugin_textdomain() {
		load_plugin_textdomain( 'like-themes-plugins', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
	}
}


add_action( 'widgets_init', 'ltx_action_widgets_init' );
if ( !function_exists('ltx_action_widgets_init')) {

	function ltx_action_widgets_init() {

		$paths = array();

		/**
		 * Widgets list
		 */
		$parent_widgets = array(
			'icons',
		);
		$parent_path = LTX_PLUGIN_DIR . 'widgets' ;

		/**
		 * Generating widgets include array
		 */
		$items = array();
		if ( !empty( $parent_widgets ) ) {

			foreach ( $parent_widgets as $item ) {

				$items[] = array( 'path' => $parent_path . '/' . $item , 'name' => $item );
			}
		}

		$included_widgets = array();
		if ( !empty( $items ) ) {

			foreach ( $items as $item ) {

				if ( isset( $included_widgets[ $item['name'] ] ) ) {
					// this happens when a widget in child theme wants to overwrite the widget from parent theme
					continue;
				} else {
					$included_widgets[ $item['name'] ] = true;
				}

				include_once ( $item['path'] . '/class-widget-' . $item['name'] . '.php' );

				$widget_class = 'Taxipark_Widget_' . ltx_widget_classname( $item['name'] );
				if ( class_exists( $widget_class ) ) {

					register_widget( $widget_class );
				}
			}
		}
	}

	function ltx_widget_classname( $widget_name ) {
		
		$class_name = explode( '-', $widget_name );
		$class_name = array_map( 'ucfirst', $class_name );
		$class_name = implode( '_', $class_name );

		return $class_name;
	}	
}

