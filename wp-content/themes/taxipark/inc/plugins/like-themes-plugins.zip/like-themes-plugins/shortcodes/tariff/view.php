<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Tariff Shortcode
 */

$args = get_query_var('like_sc_tariff');

if ( !empty($args['vip']) ) $vip = 'vip'; else $vip = '';

echo '<div class="tariff-item matchHeight '.esc_attr($vip).'">';
	if ( !empty($args['image'])) {

		$image = like_get_attachment_img_url( $args['image'] );
		echo '<div class="image"><img src="' . $image[0] . '" class="full-width" alt="'. esc_html($args['header']) .'"></div>';
	}
	if ( !empty($args['header']) ) echo '<h4>'. esc_html($args['header']) .'</h4>';
	if ( !empty($args['text']) ) echo '<p>'. wp_kses_post($args['text']) .'</p>';
	if ( !empty($args['price']) ) echo '<div class="price">' . wp_kses_post($args['price']) . '</div>';
echo '</div>';


