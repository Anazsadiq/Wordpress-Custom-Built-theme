<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Shortcode Header
 */

// Shortcode fields configuration
if ( !function_exists( 'like_vc_tariff_params' ) ) {

	function like_vc_tariff_params() {

		$fields = array(

			array(
				"param_name" => "image",
				"heading" => esc_html__("Image", 'like-themes-plugins'),
				"type" => "attach_image"
			),
			array(
				"param_name" => "header",
				"heading" => esc_html__("Header", 'like-themes-plugins'),
				"admin_label" => true,
				"type" => "textfield"
			),
			array(
				"param_name" => "text",
				"heading" => esc_html__("Description", 'like-themes-plugins'),
				"admin_label" => true,				
				"type" => "textarea"
			),
			array(
				"param_name" => "price",
				"heading" => esc_html__("Price", 'like-themes-plugins'),
				"description"	=>	esc_html__("Use {{ /km }} prefix to to set units", 'like-themes-plugins'),
				"type" => "textfield"
			),			
			array(
				"param_name" => "vip",
				"heading" => esc_html__("Vip", 'like-themes-plugins'),
				"description"	=>	esc_html__("Will be marked", 'like-themes-plugins'),
				"admin_label" => true,						
				"type" => "checkbox"
			),			
		);

		return $fields;
	}
}

// Add Wp Shortcode
if ( !function_exists( 'like_sc_tariff' ) ) {

	function like_sc_tariff($atts, $content = null) {	

		$atts = like_sc_atts_parse('like_sc_header', $atts, array_merge( array(

			'image'		=> '',
			'header' 	=> '',
			'text' 		=> '',
			'price' 	=> '',
			'vip' 	=> '',

			), array_keys(like_vc_default_params(true)) )
		);

		if (!empty($atts['header']) || !empty($atts['image'])) {

			return like_sc_output('tariff', $atts, $content);
		}
			else {

			return false;
		}
	}

	if (like_vc_inited()) add_shortcode("like_sc_tariff", "like_sc_tariff");
}


// Adding shortcode to VC
if (!function_exists('like_vc_tariff_add')) {

	function like_vc_tariff_add() {
		
		vc_map( array(
			"base" => "like_sc_tariff",
			"name" 	=> esc_html__("Tariff", 'like-themes-plugins'),
			"description" => esc_html__("Tarif Single Block", 'like-themes-plugins'),
			"class" => "like_sc_tariff",
//			"icon"	=>	likeGetPluginUrl('/shortcodes/header/icon.png'),
			"show_settings_on_create" => true,
			"category" => esc_html__('Like-Themes', 'like-themes-plugins'),
			'content_element' => true,
			"params" => array_merge(
				like_vc_tariff_params(),
				like_vc_default_params()
			)
		) );
	}

	if (like_vc_inited()) add_action('vc_before_init', 'like_vc_tariff_add', 30);
}


