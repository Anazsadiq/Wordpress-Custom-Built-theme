<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );

/**
  * Creation of custom post type
  */

function like_add_custom_post_types() {

	$labels = array(
		'name'               => esc_html__( 'Testimonials', 'like-themes-plugins' ),
		'singular_name'      => esc_html__( 'Testimonial', 'like-themes-plugins' ),
		'menu_name'          => esc_html__( 'Testimonials', 'like-themes-plugins' ),
		'name_admin_bar'     => esc_html__( 'Testimonial', 'like-themes-plugins' ),
		'add_new'            => esc_html__( 'Add New', 'like-themes-plugins' ),
		'add_new_item'       => esc_html__( 'Add New Testimonial', 'like-themes-plugins' ),
		'new_item'           => esc_html__( 'New Testimonial', 'like-themes-plugins' ),
		'edit_item'          => esc_html__( 'Edit Testimonial', 'like-themes-plugins' ),
		'view_item'          => esc_html__( 'View Testimonial', 'like-themes-plugins' ),
		'all_items'          => esc_html__( 'All Testimonials', 'like-themes-plugins' ),
		'search_items'       => esc_html__( 'Search Testimonials', 'like-themes-plugins' ),
		'parent_item_colon'  => esc_html__( 'Parent Testimonials:', 'like-themes-plugins' ),
		'not_found'          => esc_html__( 'No books found.', 'like-themes-plugins' ),
		'not_found_in_trash' => esc_html__( 'No books found in Trash.', 'like-themes-plugins' )
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_icon'			 => 'dashicons-format-status',	
		'query_var'          => true,
/*		'rewrite'            => array( 'slug' => 'testimonials' ),*/
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'thumbnail')
	);

register_post_type( 'testimonials', $args );

	$labels = array(
		'name'               => esc_html__( 'Gallery', 'like-themes-plugins' ),
		'singular_name'      => esc_html__( 'Gallery', 'like-themes-plugins' ),
		'menu_name'          => esc_html__( 'Gallery', 'like-themes-plugins' ),
		'name_admin_bar'     => esc_html__( 'Gallery', 'like-themes-plugins' ),
		'add_new'            => esc_html__( 'Add New', 'like-themes-plugins' ),
		'add_new_item'       => esc_html__( 'Add New Gallery', 'like-themes-plugins' ),
		'new_item'           => esc_html__( 'New Gallery', 'like-themes-plugins' ),
		'edit_item'          => esc_html__( 'Edit Gallery', 'like-themes-plugins' ),
		'view_item'          => esc_html__( 'View Gallery', 'like-themes-plugins' ),
		'all_items'          => esc_html__( 'All Gallery', 'like-themes-plugins' ),
		'search_items'       => esc_html__( 'Search Gallery', 'like-themes-plugins' ),
		'parent_item_colon'  => esc_html__( 'Parent Gallery:', 'like-themes-plugins' ),
		'not_found'          => esc_html__( 'No books found.', 'like-themes-plugins' ),
		'not_found_in_trash' => esc_html__( 'No books found in Trash.', 'like-themes-plugins' )
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_icon'			 => 'dashicons-images-alt',	
		'query_var'          => true,
/*		'rewrite'            => array( 'slug' => 'gallery' ),*/
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'thumbnail')
	);

	register_post_type( 'gallery', $args );

		$labels = array(
		'name'               => esc_html__( 'Sections', 'like-themes-plugins' ),
		'singular_name'      => esc_html__( 'Section', 'like-themes-plugins' ),
		'menu_name'          => esc_html__( 'Sections', 'like-themes-plugins' ),
		'name_admin_bar'     => esc_html__( 'Sections', 'like-themes-plugins' ),
		'add_new'            => esc_html__( 'Add New', 'like-themes-plugins' ),
		'add_new_item'       => esc_html__( 'Add New Section', 'like-themes-plugins' ),
		'new_item'           => esc_html__( 'New Section', 'like-themes-plugins' ),
		'edit_item'          => esc_html__( 'Edit Section', 'like-themes-plugins' ),
		'view_item'          => esc_html__( 'View Section', 'like-themes-plugins' ),
		'all_items'          => esc_html__( 'All Section', 'like-themes-plugins' ),
		'search_items'       => esc_html__( 'Search Section', 'like-themes-plugins' ),
		'parent_item_colon'  => esc_html__( 'Parent Section:', 'like-themes-plugins' ),
		'not_found'          => esc_html__( 'No books found.', 'like-themes-plugins' ),
		'not_found_in_trash' => esc_html__( 'No books found in Trash.', 'like-themes-plugins' )
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_icon'			 => 'dashicons-welcome-widgets-menus',	
		'query_var'          => true,
/*		'rewrite'            => array( 'slug' => 'gallery' ),*/
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'			 => array( 'title', 'editor')
	);

	register_post_type( 'sections', $args );
}
add_action( 'init', 'like_add_custom_post_types' );
