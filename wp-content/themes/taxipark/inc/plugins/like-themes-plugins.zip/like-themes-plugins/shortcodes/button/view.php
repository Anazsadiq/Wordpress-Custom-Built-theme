<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Button Shortcode
 */

$args = get_query_var('like_sc_button');

$attrAlign = $attr = '';
if ( !empty($args['size']) AND $args['size'] != 'default' ) $attr .= ' btn-'.$args['size'];
if ( !empty($args['color']) AND $args['color'] != 'default' ) $attr .= ' btn-'.$args['color'];
if ( !empty($args['align']) AND $args['align'] != 'default' ) { $attrAlign .= ' align-'.$args['align']; $attr .= ' align-'.$args['align']; }

echo '<div class="btn-wrap'. esc_attr( $attrAlign ) .'"><a href="'. esc_url($args['href']) .'" class="btn '. esc_attr( $attr ) .'">';
	echo esc_html( $args['header'] );
echo '</a></div>';

