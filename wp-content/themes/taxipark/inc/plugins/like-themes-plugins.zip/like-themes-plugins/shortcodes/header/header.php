<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Shortcode Header
 */

// Shortcode fields configuration
if ( !function_exists( 'like_vc_header_params' ) ) {

	function like_vc_header_params() {

		$fields = array(

			array(
				"param_name" => "type",
				"heading" => esc_html__("Header Type", 'like-themes-plugins'),
				"std" => "h2",
				"value" => array(
					esc_html__('Heading 1', 'like-themes-plugins') => 'h1',
					esc_html__('Heading 2', 'like-themes-plugins') => 'h2',
					esc_html__('Heading 3', 'like-themes-plugins') => 'h3',
					esc_html__('Heading 4', 'like-themes-plugins') => 'h4',
					esc_html__('Heading 5', 'like-themes-plugins') => 'h5',
					esc_html__('Heading 6', 'like-themes-plugins') => 'h6'
				),
				"type" => "dropdown"
			),
			array(
				"param_name" => "size",
				"heading" => esc_html__("Header Size", 'like-themes-plugins'),
				"description" => esc_html__("Larger Heading can be used for transforming H2 into H1 sized tag etc.", 'like-themes-plugins'),
				"std" => "default",
				"value" => array(
					esc_html__('Default', 'like-themes-plugins') 	=> 'default',
					esc_html__('Larger', 'like-themes-plugins') 	=> 'large',
					esc_html__('Smaller', 'like-themes-plugins') 	=> 'small',
				),
				"type" => "dropdown"
			),
			array(
				"param_name" => "style",
				"heading" => esc_html__("Header Special", 'like-themes-plugins'),
				"description" => esc_html__("Special styling", 'like-themes-plugins'),
				"std" => "default",
				"value" => array(
					esc_html__('Default', 'like-themes-plugins') 		=> 'default',
					esc_html__('Inline', 'like-themes-plugins') 	=> 'inline',
					esc_html__('Inline, subheader Larger', 'like-themes-plugins') 	=> 'spanned',
					esc_html__('Rounded background', 'like-themes-plugins') 	=> 'header-rounded',
				),
				"type" => "dropdown"
			),					
			array(
				"param_name" => "align",
				"heading" => esc_html__("Alignment", 'like-themes-plugins'),
				"description" => esc_html__("Horizontal Aligment of Header", 'like-themes-plugins'),
				"std" => "default",
				"value" => array(
					esc_html__('Default', 'like-themes-plugins') => 'default',
					esc_html__('Left', 'like-themes-plugins') => 'left',
					esc_html__('Center', 'like-themes-plugins') => 'center',
					esc_html__('Right', 'like-themes-plugins') => 'right'
				),
				"type" => "dropdown"
			),
			array(
				"param_name" => "header",
				"heading" => esc_html__("Header", 'like-themes-plugins'),
				"admin_label" => true,
				"type" => "textfield"
			),
			array(
				"param_name" => "subheader",
				"heading" => esc_html__("Subheader", 'like-themes-plugins'),
				"description" => esc_html__("Subheader will be shown in different color or on second line", 'like-themes-plugins'),
				"type" => "textfield"
			),
			array(
				"param_name" => "Link",
				"heading" => esc_html__("Link", 'like-themes-plugins'),
				"description" => esc_html__("Header link", 'like-themes-plugins'),
				"type" => "textfield"
			),			
			array(
				"param_name" => "text",
				"heading" => esc_html__("Text", 'like-themes-plugins'),
				"description" => esc_html__("Text Under Header", 'like-themes-plugins'),
				"type" => "textarea"
			),			
			array(
				'param_name' => 'icon_fontawesome',
				'heading' => esc_html__( 'Icon', 'like-themes-plugins' ),
				'description' => esc_html__("Icon will be showed before header or as background", 'like-themes-plugins'),				
				'type' => 'iconpicker',
				'admin_label' => true,						
				'value' => '',
				'settings' => array(
					'emptyIcon' => true,
					'type' => 'fontawesome'

				),
			),
			array(
				"param_name" => "icon_type",
				"heading" => esc_html__("Icon Type", 'like-themes-plugins'),
				"std" => "hidden",
				"value" => array(
					esc_html__('Hidden', 'like-themes-plugins') => 'hidden',					
					esc_html__('Before Header', 'like-themes-plugins') => 'default',
					esc_html__('As Background', 'like-themes-plugins') => 'bg',
				),
				"type" => "dropdown"
			),			
		);

		return $fields;
	}
}

// Add Wp Shortcode
if ( !function_exists( 'like_sc_header' ) ) {

	function like_sc_header($atts, $content = null) {	

		$atts = like_sc_atts_parse('like_sc_header', $atts, array_merge( array(

			'size'		=> 'default',
			'bg'		=> 'light',
			'type'		=> 'h2',
			'header' 	=> '',
			'subheader' => '',
			'style' 	=> '',
			'text' 		=> '',
			'link' 		=> '',
			'icon_fontawesome' 	=> '',
			'icon_type' 		=> 'default',
			'align' 	=> 'left',

			), array_fill_keys(array_keys(like_vc_default_params(true)), null) )
		);

		if (!empty($atts['header']) || !empty($atts['subheader'])) {

			return like_sc_output('header', $atts, $content);
		}
			else {

			return false;
		}
	}

	if (like_vc_inited()) add_shortcode("like_sc_header", "like_sc_header");
}


// Adding shortcode to VC
if (!function_exists('like_vc_header_add')) {

	function like_vc_header_add() {
		
		vc_map( array(
			"base" => "like_sc_header",
			"name" 	=> esc_html__("Header", 'like-themes-plugins'),
			"description" => esc_html__("Custom Header", 'like-themes-plugins'),
			"class" => "like_sc_header",
//			"icon"	=>	likeGetPluginUrl('/shortcodes/header/icon.png'),
			"show_settings_on_create" => true,
			"category" => esc_html__('Like-Themes', 'like-themes-plugins'),
			'content_element' => true,
			"params" => array_merge(
				like_vc_header_params(),
				like_vc_default_params()
			)
		) );
	}

	if (like_vc_inited()) add_action('vc_before_init', 'like_vc_header_add', 30);
}


