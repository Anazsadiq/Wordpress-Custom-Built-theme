<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Sliders Shortcode
 */

$args = get_query_var('like_sc_sliders');

if ( $args['type'] == 'slider-swiper' ) {

	$classText = ' swiper-gallery';
	foreach ( $args['slides'] as $item ) if (!empty($item['text'])) $classText = ' swiper-text';

	echo '<div class="slider-inner swiper-container align-' . esc_attr($args['align']) . esc_attr($classText) . '">
		<div class="swiper-wrapper">';

	foreach ( $args['slides'] as $item ) {

		$image = like_get_attachment_img_url( $item['image'] );
		if ( empty($item['text']) ) {

			echo '<div class="swiper-slide">';
				echo '<img src="' . $image[0] . '" alt="slider">';			
			echo '</div>';
		}
			else 
		if ( !empty($item['text']) ) {

			echo '<div class="swiper-slide">';

			if ($args['align'] != 'center') echo '<div class="row"><div class="col-md-6">';

			if ($args['align'] == 'center' OR $args['align'] == 'right') echo '<img src="' . $image[0] . '" alt="slider">';

			if ($args['align'] == 'right') echo '</div><div class="col-md-6">';

				echo '<div class="descr"><p>'.esc_html($item['text']).'</p>';

				if ( !empty($item['href']) ) {

					if ( empty($item['header'])) $item['header'] = esc_html__("read more", 'like-themes-plugins');

					echo '<a class="btn btn-xs" href="'. esc_url($item['href']) .'">'.esc_html($item['header']).'</a>';
				}		

				echo '</div>';

				if ($args['align'] == 'left') echo '</div><div class="col-md-6"><img src="' . $image[0] . '" alt="slider">';
			
			if ($args['align'] != 'center') echo '</div></div>';				

			echo '</div>';
		}
	}

	echo '</div>
		<div class="swiper-arrows"><a href="#" class="arrow-left"><span class="fa fa-chevron-left "></span></a><a href="#" class="arrow-right"><span class="fa fa-chevron-right"></span></a></div>
		<div class="swiper-pagination"></div>
	</div>';

}


if ( $args['type'] == 'slider-zoom' ) {

	if ( sizeof( $args['slides'] ) > 0 ) {

		$json = array();
		foreach ( $args['slides'] as $item ) {

			$image = like_get_attachment_img_url( $item['image'] );
			$json[] = $image[0];
		}

		$json = json_encode( $json );

	}
		else {

		$json = '';
	}

	echo '<div class="slider-zoom" data-zs-speed="'. esc_attr($args['zs_speed']) .'" data-zs-interval="'. esc_attr($args['zs_interval']) .'" data-zs-bullets="false" data-zs-switchSpeed="4000" data-zs-src=\''. filter_var( $json, FILTER_SANITIZE_SPECIAL_CHARS ) .'\'>
		<div class="container">
			<div class="slider-inner">
				'. do_shortcode( $content ) .'
			</div>
		</div>
	</div>';
}


