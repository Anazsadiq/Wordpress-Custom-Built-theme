<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Team Shortcode
 */

$args = get_query_var('like_sc_team');

echo '<div class="team-item matchHeight item-type-'. esc_attr($args['type']) .'">';
	if ( !empty($args['image'])) {

		$image = like_get_attachment_img_url( $args['image'] );
		echo '<div class="image"><img src="' . $image[0] . '" class="full-width" alt="'. esc_html($args['header']) .'"></div>';
	}
	if ( !empty($args['header']) ) echo '<h4>'. esc_html($args['header']) .'</h4>';
	if ( !empty($args['text']) ) echo '<p>'. wp_kses_post($args['text']) .'</p>';

	if ( !empty($atts['icons']) ) {

		echo '<div class="social"><ul>';
		foreach ( $atts['icons'] as $item ) {

			if ( empty($item['href']) ) $item['href'] = '#';

			echo '<li><a href="'. esc_url( $item['href'] ) .'"><span class="'. esc_attr( $item['icon_fontawesome'] ) .'"></span></a></li>';
		}

		echo '</ul></div>';
	}

echo '</div>';


