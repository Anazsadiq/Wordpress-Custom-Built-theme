<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Social Icons Shortcode
 */

$args = get_query_var('like_sc_social_icons');

$class = '';
if ( $atts['type'] == 'icons-list' ) $class = 'social-icons-list';
if ( $atts['type'] == 'icons-inline-large' ) $class = 'social-big';
if ( $atts['type'] == 'icons-inline-small' ) $class = 'social-small';

echo '<div class="align-'. esc_attr($atts['align']) .'"><ul class="'. esc_attr($class) .'">';
	foreach ( $atts['icons'] as $item ) {

		$li_class = '';
		if ($item['size'] == 'large') $li_class = 'large';

		if ( $atts['type'] == 'icons-list' ) {

			if ( empty( $item['href'] ) ) {

				echo '<li class="'. esc_attr($li_class) .'"><span class="'. esc_attr( $item['icon_fontawesome'] ) .'"></span>'. esc_html( $item['header'] ) .'</li>';
			}
				else {

				echo '<li class="'. esc_attr($li_class) .'"><a href="'. esc_url( $item['href'] ) .'"><span class="'. esc_attr( $item['icon_fontawesome'] ) .'"></span>'. esc_html( $item['header'] ) .'</a></li>';
			}
		}
			else {

			if (empty($item['href'])) $item['href'] = '#';

			echo '<li><a href="'. esc_url( $item['href'] ) .'" class="'. esc_attr( $item['icon_fontawesome'] ) .'"></a></li>';
		}	
	}
echo '</ul></div>';

