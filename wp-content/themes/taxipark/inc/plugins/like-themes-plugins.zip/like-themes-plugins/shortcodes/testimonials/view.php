<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Testimonials Shortcode
 */

$args = get_query_var('like_sc_testimonials');

$query_args = array(
	'post_type' => 'testimonials',
	'post_status' => 'publish',
	'posts_per_page' => 6,
);

$query = new WP_Query( $query_args );

if ( $query->have_posts() ) {

	echo '<div class="swiper-container testimonials-list testimonials-slider row">
			<div class="swiper-wrapper">';

	while ( $query->have_posts() ) {

		$query->the_post();

		echo '
		<div class="col-md-4 col-sm-6 swiper-slide">
			<article class="inner matchHeight">
				<div class="text">
					<p>'. get_the_content() .'</p>
				</div>
				<div class="quote">
					<span class="fa fa-quote-left"></span>
					<div class="name">'. get_the_title() .'</div>';
					echo the_post_thumbnail( 'stargym-test' );
		echo '	</div>
			</article>
		</div>';
		
	}

	echo '
		    </div>
			<div class="arrows">
				<a href="#" class="arrow-left fa fa-caret-left"></a>
				<a href="#" class="arrow-right fa fa-caret-right"></a>
			</div>
		</div>';

	wp_reset_postdata();
}

