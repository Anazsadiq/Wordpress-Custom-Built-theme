<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Shortcode Header
 */

// Shortcode fields configuration
if ( !function_exists( 'like_vc_testimonials_params' ) ) {

	function like_vc_testimonials_params() {

		$fields = array(
		);

		return $fields;
	}
}

// Add Wp Shortcode
if ( !function_exists( 'like_sc_testimonials' ) ) {

	function like_sc_testimonials($atts, $content = null) {	

		return like_sc_output('testimonials', $atts, $content);
	}

	if (like_vc_inited()) add_shortcode("like_sc_testimonials", "like_sc_testimonials");
}


// Adding shortcode to VC
if (!function_exists('like_vc_testimonials_add')) {

	function like_vc_testimonials_add() {
		
		vc_map( array(
			"base" => "like_sc_testimonials",
			"name" 	=> esc_html__("Testimonials", 'like-themes-plugins'),
			"description" => esc_html__("Testimonials Slider", 'like-themes-plugins'),
			"class" => "like_sc_testimonials",
//			"icon"	=>	likeGetPluginUrl('/shortcodes/header/icon.png'),
			"show_settings_on_create" => true,
			"category" => esc_html__('Like-Themes', 'like-themes-plugins'),
			'content_element' => true,
			"params" => array_merge(
				like_vc_testimonials_params(),
				like_vc_default_params()
			)
		) );
	}

	if (like_vc_inited()) add_action('vc_before_init', 'like_vc_testimonials_add', 30);
}


